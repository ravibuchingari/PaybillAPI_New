﻿namespace PaybillAPI.Models
{
    public class ChartData
    {
        public float YAxis { get; set; }
        public string XLabel { get; set; } = null!;
    }
}
