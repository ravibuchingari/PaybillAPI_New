﻿namespace PaybillAPI.ViewModel
{
    public class CategoryVM
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; } = null!;
        public int ItemCount { get; set; }
    }
}
