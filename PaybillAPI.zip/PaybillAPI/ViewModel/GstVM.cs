﻿namespace PaybillAPI.ViewModel
{
    public class GstVM
    {
        public int GstId { get; set; }

        public float CgstPer { get; set; }

        public float SgstPer { get; set; }

        public float IgstPer { get; set; }

        public bool IsActive { get; set; }
    }
}
